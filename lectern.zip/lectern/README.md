# Lectern: a self-hosted read-aloud app

Add PDFs, Word files, web links or pasted text; listen with sentence highlighting,
speed control, click-to-seek, resume position, and WAV export. Library is stored in your browser.

## Run
```bash
# 1. system dependency for Kokoro (skip for mock mode)
sudo apt install espeak-ng        # macOS: brew install espeak-ng

# 2. python deps
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt   # Kokoro pulls in torch (large)

# 3. start
cd backend && uvicorn server:app --port 8000
# open http://localhost:8000
```
No Kokoro yet? `LECTERN_ENGINE=mock uvicorn server:app` plays placeholder tones so you can test the UI.

## Swapping the voice engine
`backend/engines.py`: subclass `Engine`, implement `synth(text, voice) -> int16 mono PCM bytes`,
set `sample_rate`, `voices`, `default_voice`, and return it from `load_engine()`.
Kokoro voices are listed in `KokoroEngine.voices` (any id from the model's VOICES.md works; first letter picks the language).

## Layout
- `backend/server.py` API (voices, tts, clean, extract, extract-url, export) + serves the UI
- `backend/extract.py`, `textprep.py` file/URL extraction and text cleanup
- `frontend/js/` chunker, player (prefetch + gapless), reader, IndexedDB library, app wiring

## Not verified here
I had no network or GPU in my sandbox, so Kokoro and the server were not run end-to-end;
the Python compiles, the mock engine and cleaner ran, and the JS passes syntax checks and a chunker test.
Likely first-run snags: espeak-ng missing, first synth is slow while weights download.
